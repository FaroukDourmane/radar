(function ($) {
    'use strict';

    // :: Nice Select Active Code
    if ($.fn.niceSelect) {
        $('select').niceSelect();
    }

})(jQuery);
